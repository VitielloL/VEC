---
title: Box seam fill
categories:
  - Real world
tags:
  - cardboard
  - package
---
