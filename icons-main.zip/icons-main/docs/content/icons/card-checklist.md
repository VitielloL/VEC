---
title: Card checklist
categories:
  - Files and folders
tags:
  - note
  - card
  - notecard
---
