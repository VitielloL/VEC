---
title: Arrow up right square
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---
