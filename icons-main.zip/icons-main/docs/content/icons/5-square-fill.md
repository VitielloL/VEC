---
title: 5 square fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
