---
title: 2 circle fill
categories:
  - Shapes
tags:
  - number
  - numeral
---
