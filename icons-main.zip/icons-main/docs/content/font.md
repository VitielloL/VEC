---
title: Icon Font
description: Use Bootstrap Icons as an icon font, built from our SVGs and easily customized with CSS.
layout: font
---
